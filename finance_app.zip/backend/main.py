from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import database, crud, models
from .schemas import TransactionCreate, TransactionOut, PortfolioValue, InstrumentCreate
from sqlalchemy.orm import Session
from fastapi.concurrency import run_in_threadpool
import asyncio
import random

app = FastAPI(title='Finance API')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

database.init_db()

async def fetch_market_price(symbol: str) -> float:
    await asyncio.sleep(0.05)
    r = (abs(hash(symbol)) % 10000) / 10.0
    return round(r * (0.8 + 0.4 * random.random()), 2)

@app.get('/api/portfolio/value', response_model=PortfolioValue)
async def portfolio_value():
    def market_price_lookup(sym: str):
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(fetch_market_price(sym))

    def db_work():
        db = Session(bind=database.engine)
        try:
            return crud.compute_portfolio_value(db, market_price_lookup)
        finally:
            db.close()

    res = await run_in_threadpool(db_work)
    return res

@app.get('/api/transactions', response_model=list[TransactionOut])
async def get_txns():
    def db_work():
        db = Session(bind=database.engine)
        try:
            return crud.get_transactions(db)
        finally:
            db.close()
    txns = await run_in_threadpool(db_work)
    return txns

@app.post('/api/transactions', response_model=TransactionOut)
async def post_txn(txn_in: TransactionCreate):
    def db_work():
        db = Session(bind=database.engine)
        try:
            t = models.Transaction(
                account_id=txn_in.account_id,
                instrument_id=txn_in.instrument_id,
                amount=txn_in.amount,
                currency=txn_in.currency,
            )
            db.add(t)
            db.commit()
            db.refresh(t)
            return t
        finally:
            db.close()

    t = await run_in_threadpool(db_work)
    return t

@app.post('/api/instruments')
async def add_instrument(instr: InstrumentCreate):
    def db_work():
        db = Session(bind=database.engine)
        try:
            i = models.Instrument(symbol=instr.symbol.upper(), name=instr.name)
            db.add(i)
            db.commit()
            db.refresh(i)
            return {'id': i.id, 'symbol': i.symbol}
        finally:
            db.close()
    return await run_in_threadpool(db_work)

@app.get('/api/markets/{symbol}')
async def market_price(symbol: str):
    price = await fetch_market_price(symbol.upper())
    return {'symbol': symbol.upper(), 'price': price}
