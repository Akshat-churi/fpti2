from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base
import datetime

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    accounts = relationship('Account', back_populates='user')

class Account(Base):
    __tablename__ = 'accounts'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String)
    account_type = Column(String)
    user = relationship('User', back_populates='accounts')
    transactions = relationship('Transaction', back_populates='account')

class Instrument(Base):
    __tablename__ = 'instruments'
    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String, unique=True, nullable=False)
    name = Column(String)

class Transaction(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey('accounts.id'))
    instrument_id = Column(Integer, ForeignKey('instruments.id'), nullable=True)
    amount = Column(Float, nullable=False)
    currency = Column(String, default='INR')
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

    account = relationship('Account', back_populates='transactions')
    instrument = relationship('Instrument')
