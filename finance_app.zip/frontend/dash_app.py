import dash
from dash import dcc, html, Output, Input
import requests
import pandas as pd
import plotly.express as px

BACKEND = 'http://127.0.0.1:8000'

app = dash.Dash(__name__)
server = app.server

app.layout = html.Div([
    html.H2('Finance Dashboard — Net Worth & Portfolio'),
    html.Div([
        html.Button('Refresh', id='refresh-btn'),
        dcc.Dropdown(id='symbol-input', options=[], placeholder='Select symbol...')
    ]),
    dcc.Graph(id='networth-graph'),
    dcc.Graph(id='allocation-pie')
])

@app.callback(
    Output('networth-graph', 'figure'),
    Output('allocation-pie', 'figure'),
    Input('refresh-btn', 'n_clicks'))
def refresh(_):
    r = requests.get(BACKEND + '/api/portfolio/value')
    data = r.json()

    total = data['total_value']
    cash = data.get('cash', 0.0)
    breakdown = data.get('breakdown', {})

    years = list(range(2016, 2026))
    values = [total * (0.9 + 0.02 * i) for i in range(len(years))]
    df = pd.DataFrame({'year': years, 'net_worth': values})
    fig1 = px.line(df, x='year', y='net_worth', title='Net Worth Timeline')

    labels = []
    vals = []
    labels.append('Cash')
    vals.append(cash)
    for sym, info in breakdown.items():
        labels.append(sym)
        vals.append(info['value'])
    alloc_df = pd.DataFrame({'label': labels, 'value': vals})
    fig2 = px.pie(alloc_df, names='label', values='value', title='Asset Allocation')

    return fig1, fig2

if __name__ == '__main__':
    app.run_server(debug=True, port=8050)
